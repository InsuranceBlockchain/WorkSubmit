package main

import "fmt"

type client struct {
	name string
	flight_code string
	flight_data string
	claim_amount int
}

func init(){
	fmt.ScanIn(&name, &flight_code, &flight_data, &claim_amount)
}

func submit_proposal(clientA client){
	result, trans_info := invokeCmd(clientA) /*调用invoke将请求发送给Endorse Peer*/
	if result = 1
		return 1, "", trans_info
	else return 0, "Claim rejected", trans_info
}

func invoke(clientA client){
	result, result_code, trans_info := submit_proposal(clientA)
	CreateStatusReply(trans_info) /*调用order提交交易*/
	broadcastMsgTracer() /*调用order将排完序的交易封装到区块*/
	updateTrustedRoots() /*调用serve将将区块发送给Commit Peer*/
	
	if result = 1 {
		Invoke(company_client.name, clientA.name, clientA.claim_amount) /*调用转账的chaincode*/
	}
	else {
		printIn(result_code)
	}
}

func main(){
	init()
	invoke(clientA)
}
