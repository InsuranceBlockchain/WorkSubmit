
package main
import (
    "io/ioutil"
    "net/http"
    "net/url"
    "fmt"
    "encoding/json"
)

const APPKEY = "e67d269aa8d144418abd3d092c0c068a" 
 
func main(){
    Request()
}
 
func Request(){
    juheURL :="http://op.juhe.cn/flight/df/fs"
 
    param:=url.Values{}
 
    param.Set("key",APPKEY) 
    param.Set("dtype","") 
    param.Set("orgCity","") //始发城市的三字码
    param.Set("dstCity","") //到达城市的三字码
    param.Set("flightNo","") //航班号
    param.Set("flightDate","") //（年月日）
    param.Set(" ","") //
 
    data,err:=Get(juheURL,param)
    if err!=nil{
        fmt.Errorf("请求失败,错误信息:\r\n%v",err)
    }else{
        var netReturn map[string]interface{}
        json.Unmarshal(data,&netReturn)
        if netReturn["error_code"].(float64)==0{
            fmt.Printf("接口返回result字段是:\r\n%v",netReturn["result"])
        }
    }
}

func Get(apiURL string,params url.Values)(rs[]byte ,err error){
    var Url *url.URL
    Url,err=url.Parse(apiURL)
    if err!=nil{
        fmt.Printf("解析url错误:\r\n%v",err)
        return nil,err
    }
    Url.RawQuery=params.Encode()
    resp,err:=http.Get(Url.String())
    if err!=nil{
        fmt.Println("err:",err)
        return nil,err
    }
    defer resp.Body.Close()
    return ioutil.ReadAll(resp.Body)
}
 
func Post(apiURL string, params url.Values)(rs[]byte,err error){
    resp,err:=http.PostForm(apiURL, params)
    if err!=nil{
        return nil ,err
    }
    defer resp.Body.Close()
    return ioutil.ReadAll(resp.Body)
}
